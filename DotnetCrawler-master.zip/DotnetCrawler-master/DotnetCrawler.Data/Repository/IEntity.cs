﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotnetCrawler.Data.Repository
{
    public interface IEntity
    {
        int Id { get; }
    }
}
