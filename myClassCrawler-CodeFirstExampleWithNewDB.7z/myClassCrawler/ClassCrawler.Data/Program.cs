﻿using System;
using Microsoft.EntityFrameworkCore;


namespace ClassCrawler.Data.Models
{
    class Program
    {
        static void Main(string[] args)
        {
            
     
        }

    }
}
