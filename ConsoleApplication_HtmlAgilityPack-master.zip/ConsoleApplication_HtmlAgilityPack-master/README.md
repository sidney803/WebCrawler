# [C#] 使用 HtmlAgilityPack 來採集網頁


教學：<a href="https://blog.sofast.info/2016/07/c-use-the-htmlagilitypack-to-collect-web-pages/">https://blog.sofast.info/2016/07/c-use-the-htmlagilitypack-to-collect-web-pages/</a>
