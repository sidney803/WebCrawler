﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DotnetCrawler.Core
{
    public interface IDotnetCrawler
    {
        Task Crawle();
    }
}
